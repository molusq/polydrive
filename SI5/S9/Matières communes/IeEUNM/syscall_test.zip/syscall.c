#include <stdio.h>
#include <stdlib.h>
#include <asm/unistd.h>
#include <sys/syscall.h>
#include <errno.h>

const int constant = 100;

/* Programme utilisateur */
main()
{
  int resultat;
  printf("Code de retour %d\n", syscall(__NR_addition, 1, 2, &resultat));
  perror("appel");
  printf("Resultat = %d\n", resultat);

  printf("Code de retour %d\n", syscall(__NR_addition, 100, 200, NULL));
  perror("appel");

  errno = 0;
  printf("Increment retcode=%d\n", syscall(__NR_increment, &resultat));
  perror("appel");
  printf("Resultat = %d\n", resultat);
  
  errno = 0;
  printf("Increment retcode=%d\n", syscall(__NR_increment, &constant));
  perror("appel");
  printf("Resultat = %d\n", constant);

  return 0;
}
