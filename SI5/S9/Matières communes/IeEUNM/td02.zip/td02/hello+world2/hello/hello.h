// Define the print_hello function
void print_hello(void);