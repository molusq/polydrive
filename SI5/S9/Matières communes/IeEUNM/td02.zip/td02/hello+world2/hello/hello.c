#include <linux/init.h> /* permet d'utiliser les macro module_init et exit */
#include <linux/module.h> /* necessaire pour la definition d'un module */

MODULE_AUTHOR("Stephane Lavirotte");
MODULE_DESCRIPTION("TD 3 / 2.1.3");
MODULE_LICENSE("GPL");

//extern void print_hello(void);
#include "hello.h"

static int init_func(void) {
  printk("Module hello init\n");
  return 0;
}

static void exit_func(void) {
  printk("Module hello exit\n");
}

void print_hello(void) {
  printk("Print Hello\n");
}

EXPORT_SYMBOL(print_hello);

module_init(init_func);
module_exit(exit_func);

