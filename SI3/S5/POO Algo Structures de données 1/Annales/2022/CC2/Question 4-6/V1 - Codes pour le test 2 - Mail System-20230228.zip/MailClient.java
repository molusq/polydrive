package test3.mailsystem;
/**
 * A class to model a simple email client. The client is run by a particular
 * user, and sends and retrieves mail via a particular server.
 *
 * @author David J. Barnes and Michael Kolling
 * @author MBF
 */

public class MailClient implements MailClientInterface {
    //The server used for sending and receiving.

    //The user  running this client.

    /**
     * Create a mail client run by user and dependent on the the given server.
     */
    MailClient(MailServer server, String user) {
    }

    /**
     * Return the next mail item (if any) for this user presents on the linked server
     * else return null;
     */
    @Override
    public MailItem getNextMailItem() {
        return null;
    }

    /**
     * Returns the next mail item (if any) for this user as a string
     */
    @Override
    public String nextMailItemToString() {
            return "No new mail.";
    }

    /**
     * Send the given message to the given recipient via the attached mail
     * server.
     *
     * @param to      The intended recipient.
     * @param message The text of the message to be sent.
     * @return true if the item was sent; false otherwise.
     */
    @Override
    public boolean sendMailItem(String to, String message) {
        return false;
    }


    //It is better to work on the tests than on the hand!  These codes are only there to help understand.
    public static void main(String[] args) {
        // ---------------
        String JOHN = "John";
        String PAUL = "Paul";
        String MSG = "Yo! Ni hao! Tervist!";
        MailServer server = new MailServer();
        MailClient johnMailClient = new MailClient(server, JOHN);
        MailClient paulMailClient = new MailClient(server, PAUL);
        johnMailClient.sendMailItem(PAUL, MSG);
        johnMailClient.sendMailItem(PAUL, MSG);
        System.out.println(paulMailClient.nextMailItemToString());
        System.out.println(paulMailClient.nextMailItemToString());
        System.out.println(paulMailClient.nextMailItemToString());
    }


    /**
     *
     * @return the name of the user of the mail client
     */
    @Override
    public String getUser() {
        return "";
    }

}