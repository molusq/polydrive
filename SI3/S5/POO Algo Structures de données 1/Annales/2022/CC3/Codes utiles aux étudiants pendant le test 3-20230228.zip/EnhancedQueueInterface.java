
public interface EnhancedQueueInterface<T> extends QueueInterface<T>{
    EnhancedQueueInterface<T> copy();
}
