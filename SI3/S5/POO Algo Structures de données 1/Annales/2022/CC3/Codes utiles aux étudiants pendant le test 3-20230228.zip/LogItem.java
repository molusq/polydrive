
public interface LogItem <V> {
    String getAction();
    V getValue();
}
