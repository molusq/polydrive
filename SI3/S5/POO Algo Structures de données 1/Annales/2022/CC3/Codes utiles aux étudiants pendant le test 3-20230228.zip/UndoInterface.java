interface UndoInterface {
    boolean undo();
}
