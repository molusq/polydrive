

/**
 * An exception class for empty stack
 */
public class EmptyStackException extends Exception {
	public EmptyStackException() {
		super();
	}
}
