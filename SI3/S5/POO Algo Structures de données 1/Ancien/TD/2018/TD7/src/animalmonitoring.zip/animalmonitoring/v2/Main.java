package animalmonitoring.v1;

import java.util.Set;

class Main{
	public static void main(String[] args) {
		System.out.println();	
	}
}