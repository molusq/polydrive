package edu.fredrallo.mvc;

import android.app.Application;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ListView;

import java.util.Observer;

import edu.fredrallo.mvc.demo.Controller_Kindergarten;
import edu.fredrallo.mvc.demo.Model_Kindergarten;
import edu.fredrallo.mvc.demo.View_Kindergarten;

/**
 * This app purpose MVC pattern (try to use MVC) to manage teams kids for a camp game
 * We display only TEAM1
 * When we click on one kid name (in a ListView) it removes from the Model and so, disapear
 * We can Add a Kid to the TEAM1 by click on left Button (TEAM2 on right button, not implemented)
 *
 *
 * MVC pattern
 *
 *                   Controller
 *                    /      |\
 *                  /          \
 *                /             \
 *             |/_                \
 *          Model    ------->   View
 *
 * links:
 *  - View -- user actions --> Controller       (onClickItem() called if user want to remove)
 *  - Controller --> update model --> Model     (call add() and remove() methods)
 *  - Model --> model changed --> Controller    (not used in this exercice)
 *  - Model --> model changed --> View          (using observer/observable --> model is observable, so when changed rollback in the update() method)
 *  - Controller --> update UI --> View         (for instance, blind a button if necessary)
 *
 *  NOTE:
 *  - in this application, Model is a singleton
 *  - link Controller --> update UI --> View         (nothing to do in this application)
 *  - link Model -- model changed --> Controller     (nothing to do in this application)
 *
 * Created by fred on 17/03/2018.
 **/
public class ApplicationKindergarten extends Application {
    private final String TAG = "frallo " + getClass().getSimpleName();
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "APPLICATION START " );
    }


    public <T extends ViewGroup> void onViewCreated(T layout) {
        //create VIEW with XML layout
        View_Kindergarten view = new View_Kindergarten( getApplicationContext(), layout );
        Model_Kindergarten model = new Model_Kindergarten(null);    //controller not still created so the controller reference will be sent later
        model.addObserver(view);    //MODEL is observable from VIEW
        model.populate();

        Controller_Kindergarten controller = new Controller_Kindergarten( view, model );
        model.setController(controller);    //sent for principe but in this exercice, MODEL doesn't need controller
        view.setListener( controller );

    }

}
