package edu.fredrallo.mvc;

import android.app.Activity;
import android.os.Bundle;

/**
 * MVC pattern - This activity inflate the view and notify application
 **/
public class MainActivity extends Activity{
    private final String TAG = "frallo " + getClass().getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ((ApplicationKindergarten)getApplication()).onViewCreated(  findViewById(R.id.view_kindergarten) );
    }

}