package edu.fredrallo.mvc.demo;

import android.content.Context;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;

import java.util.Observable;
import java.util.Observer;

import edu.fredrallo.mvc.IViewClick;
import edu.fredrallo.mvc.R;
import edu.fredrallo.mvc.ViewAdapter;


/**
 * MVC pattern - This is the View
 *
 * The View module har the responsability to inform controller when user click on an item
 * the View is an observer to the Model module
 */
public class View_Kindergarten implements Observer{
    private final String TAG = "frallo " + getClass().getSimpleName();
    private  ViewAdapter adapter;
    private ViewGroup layout;
    private boolean modelCreated = false;
    IViewClick controller;


    public <T extends ViewGroup> View_Kindergarten(Context context, T layout) {
        adapter = new ViewAdapter(context, this); //carrefull, model is null !
        this.layout = layout;
        Log.d(TAG, "View is created" );
    }

    public ViewGroup getLayout() {
        return layout;
    }

    public void setListener(IViewClick controller) {
        this.controller = controller;
    }

    public void onClickItem(int position){
        controller.onClickItem(position);
    }


    @Override
    public void update(Observable observable, Object otherData) {
        Model_Kindergarten model = (Model_Kindergarten) observable;
        if (!modelCreated) {        //fist time only
            adapter.updateModel(model);
            ListView listView = ((ListView)layout.findViewById(R.id.listviewTeam1));
            listView.setAdapter( adapter );
            modelCreated = true;
        }
        else {
            adapter.refresh(model);
        }
        Log.d(TAG, "View update with ==> " + model);
    }
}
