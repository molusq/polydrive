package edu.fredrallo.mvc;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;

import java.util.Observable;
import java.util.Observer;

import edu.fredrallo.mvc.demo.Model_Kindergarten;
import edu.fredrallo.mvc.demo.View_Kindergarten;


/**
 * MVC pattern - This is the View
 *
 Lorsque l’utilisateur agit sur la Vue, celle-ci informe le Contrôleur
 Le Contrôleur peut demander de mettre à jour la Vue (masquer…)
 Lorsque le Modèle change, la Vue qui l’observait se met à jour
 */
public class ViewAdapter extends BaseAdapter {
    private final String TAG = "frallo " + getClass().getSimpleName();
    private LayoutInflater inflater;
    private Model_Kindergarten model;
    private View_Kindergarten viewKindergarten;


    public <T extends ViewGroup> ViewAdapter(Context context, View_Kindergarten viewKindergarten) {
        inflater = LayoutInflater.from(context);
        this.viewKindergarten = viewKindergarten;
    }



    public int getCount() {
        return model.size();
    }
    public Object getItem(int position) {
        return model.get(position);
    }
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        ConstraintLayout layoutItem;

        //(1) : Réutilisation des layouts
        layoutItem = (ConstraintLayout) (view == null ? inflater.inflate(R.layout.view_adapter, parent, false) : view);

        //(2) : Récupération des TextView de notre layout
        TextView name = layoutItem.findViewById(R.id.name);

        //(3) : Renseignement des valeurs
        name.setText( model.get(position)+"" );

        //écouter si clic sur la vue
        layoutItem.setOnClickListener( clic ->  viewKindergarten.onClickItem(position) );

        //On retourne l'item créé.
        return layoutItem;
    }




    public void refresh(Model_Kindergarten model) {
        updateModel(model);
        Log.d(TAG, "listView refreshed with ==> " + model);
        //todo check team==TEAM1
        notifyDataSetChanged();     //refresh display
    }

    public void updateModel(Model_Kindergarten model) {
        this.model = model;
    }
}
