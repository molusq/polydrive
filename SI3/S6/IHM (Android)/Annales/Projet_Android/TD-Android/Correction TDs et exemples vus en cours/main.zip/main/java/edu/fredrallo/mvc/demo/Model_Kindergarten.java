package edu.fredrallo.mvc.demo;

import android.util.Log;
import android.util.Pair;

import java.util.ArrayList;
import java.util.List;
import java.util.Observable;

import edu.fredrallo.mvc.IViewClick;

/**
 * MVC pattern - This is the Model
 *
 * Model module has the responsability to notify observers (the View) when it changes
 * Model has also the responsability to inform controller when change ==> not implemented in this exercice, cause not needed
 **/
public class Model_Kindergarten extends Observable  {
     private final String TAG = "frallo " + getClass().getSimpleName();
     private List<Pair<Team,String>> completeList;
     //todo: change nothing to do with it in thi exercice
    private Controller_Kindergarten controller;     //nothing to do with it in thi exercice

    public void setController(Controller_Kindergarten controller) {
        this.controller = controller;
    }


    public enum Team {
         TEAM1,
         TEAM2;
     }

    public Model_Kindergarten(Controller_Kindergarten controller){
        super();
        this.controller = controller;
        completeList = new ArrayList<>();
        Log.d(TAG, "Model is created");
    }

    public void populate(){
        completeList.add(new Pair(Team.TEAM1, "marco"));
        completeList.add(new Pair(Team.TEAM1, "eric"));
        completeList.add(new Pair(Team.TEAM1, "noé"));
        completeList.add(new Pair(Team.TEAM1, "james"));
        completeList.add(new Pair(Team.TEAM1, "jules"));
        completeList.add(new Pair(Team.TEAM1, "bill"));
        completeList.add(new Pair(Team.TEAM1, "ugo"));
        completeList.add(new Pair(Team.TEAM1, "marie"));
        completeList.add(new Pair(Team.TEAM1, "émile"));
        completeList.add(new Pair(Team.TEAM1, "john"));
        completeList.add(new Pair(Team.TEAM1, "tom"));
        completeList.add(new Pair(Team.TEAM1, "maxandre"));
        completeList.add(new Pair(Team.TEAM1, "nathan"));
        completeList.add(new Pair(Team.TEAM1, "charlotte"));
        completeList.add(new Pair(Team.TEAM2, "marie"));
        completeList.add(new Pair(Team.TEAM2, "julia"));
        completeList.add(new Pair(Team.TEAM2, "luna"));
        completeList.add(new Pair(Team.TEAM2, "émilie"));
        completeList.add(new Pair(Team.TEAM2, "karine"));
        completeList.add(new Pair(Team.TEAM2, "chloé"));
        completeList.add(new Pair(Team.TEAM2, "emma"));
        setChanged();
        notifyObservers();
        Log.d(TAG, "Model full");
    }


     public Object get(int position) {
         return completeList.get(position).second;
     }

     public int size() {
         return completeList.size();
     }


    public void add(Team team, String name) {
        if ( team.equals(Team.TEAM1) || team.equals(Team.TEAM2) ) {
            completeList.add(new Pair(team, name));
            setChanged();
            notifyObservers();
        }
    }

    public void remove(int index) {

        if (index<completeList.size()) {
            completeList.remove(index);
            setChanged();
            notifyObservers();
        }
    }


    @Override
    public String toString() {
        StringBuilder stringBuilder=new StringBuilder("Model_Kindergarten{");
        completeList.forEach( pair -> stringBuilder.append(pair.second+", ") );  //todo remove last ','
        return "Model_Kindergarten{" + stringBuilder +"}";
    }
}
