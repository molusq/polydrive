package edu.fredrallo.mvc.demo;

import android.animation.PropertyValuesHolder;
import android.graphics.Color;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;

import edu.fredrallo.mvc.IViewClick;
import edu.fredrallo.mvc.R;


/**
 * MVC pattern - This is the Controller
 *
 * Controller module has the responsability to inform Model and View to change
 */
public class Controller_Kindergarten implements IViewClick {
    private final String TAG = "frallo " + getClass().getSimpleName();
    private View_Kindergarten view;
    private Model_Kindergarten model;



    /**
     *  @param view the view to up to date
     * @param model
     */
    public Controller_Kindergarten(View_Kindergarten view, Model_Kindergarten model) {
        Log.d(TAG, "Controller is created" );
        this.view = view;
        this.model = model;
        LinearLayout manage = ((ConstraintLayout)view.getLayout()).findViewById(R.id.manage);
        manage.findViewById(R.id.addTeam1).setOnClickListener( click ->  addPersonInTeam( manage, Model_Kindergarten.Team.TEAM1));
    }


    /**
     * update the model and update UI
     * @param manage
     * @param team
     */
    private void addPersonInTeam(ViewGroup manage, Model_Kindergarten.Team team) {
        String name = ((EditText)manage.findViewById(R.id.input_name)).getText().toString();
        Log.d(TAG, "add team="+team );
        if ( !name.equals("") ) {
            model.add(team, name);
            if (model.size() > 0) {
                TextView label = ((ConstraintLayout) view.getLayout()).findViewById(R.id.labelTeam1);
                label.setTextColor(Color.RED);
            }
        }
    }


    /**
     * callback from View
     * controller doesn't notify the view ! 'cause it's the model responsability !!!
     * @param position
     */
    @Override
    public void onClickItem(int position) {//TODO: empty edittext when used
        Log.d(TAG, "item clicked = " + position );
        if (model.size()>0) {
            model.remove(position);
            if (model.size() == 0) {
                Log.d(TAG, "empty team");
                TextView label = ((ConstraintLayout) view.getLayout()).findViewById(R.id.labelTeam1);
                label.setTextColor(Color.BLACK);
            }
        }
    }
}
