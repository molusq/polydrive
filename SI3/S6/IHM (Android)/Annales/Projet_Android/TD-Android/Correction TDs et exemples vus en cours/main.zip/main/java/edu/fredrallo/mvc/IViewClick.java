package edu.fredrallo.mvc;

public interface IViewClick {
    void onClickItem(int position);
}
