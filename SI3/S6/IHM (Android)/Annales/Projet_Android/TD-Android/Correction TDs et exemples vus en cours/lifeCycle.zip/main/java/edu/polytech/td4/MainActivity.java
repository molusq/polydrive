package edu.polytech.td4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity{
    private ArrayList<CharSequence> activityList;
    private TextView stateTextView;
    private int shift;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("MainActivity_monitor", "onCreate() in running");
        setContentView(R.layout.activity_main);

        //load shift value from another intent
        Intent intentReceive = getIntent();
        shift = intentReceive.getIntExtra(getString(R.string.NB_SHIFT), 0);

        activityList = intentReceive.getCharSequenceArrayListExtra(getString(R.string.LIST));

        if (activityList == null) {  activityList = new ArrayList(); } else { activityList.add("\n"); }
        activityList.add(shift + " --> ");
        stateTextView = findViewById(R.id.currentState);
        stateTextView.setTextSize(14);

        activityList.add("onCreate");
        stateTextView.setText(activityList + "");

        (findViewById(R.id.button)).setOnClickListener(click -> {
            Intent intentSend = new Intent(getApplicationContext(), ImageActivity.class);
            intentSend.putExtra(getString(R.string.NB_SHIFT), ++shift);
            intentSend.putCharSequenceArrayListExtra(getString(R.string.LIST), activityList);
            startActivity(intentSend);
        });
    }


    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d("MainActivity_monitor","onRestart() in running");
        activityList.add("onRestart");
        stateTextView.setText(activityList+"");
    }


    @Override
    protected void onStart() {
        super.onStart();
        Log.d("MainActivity_monitor","onStart() in running");
        activityList.add("onRestart");
        stateTextView.setText(activityList+"");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("MainActivity_monitor", "onResume() in running");
        activityList.add("onResume");
        stateTextView.setText(activityList+"");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("MainActivity_monitor", "onPause() in running");
        activityList.add("onPause");
        stateTextView.setText(activityList+"");
    }


    @Override
    protected void onStop() {
        super.onStop();
        Log.d("MainActivity_monitor", "onStop() in running");
        activityList.add("onStop");
        stateTextView.setText(activityList+"");
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("MainActivity_monitor", "onDestroy() in running");
        activityList.add("onDestroy");
        stateTextView.setText(activityList+"");
    }
}
