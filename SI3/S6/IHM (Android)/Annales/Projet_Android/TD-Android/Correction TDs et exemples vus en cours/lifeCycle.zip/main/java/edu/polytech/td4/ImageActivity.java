package edu.polytech.td4;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;


public class ImageActivity extends AppCompatActivity{
    ArrayList<CharSequence> activityList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image);
        //récupération des éléments de l'activité appelante
        Intent intentReceive = getIntent();
        int nbShift=intentReceive.getIntExtra(getString(R.string.NB_SHIFT),0);
        activityList=intentReceive.getCharSequenceArrayListExtra(getString(R.string.LIST));

        ((TextView) findViewById(R.id.textView)).setText("current nb of activity shifts = " + nbShift );
        (findViewById(R.id.button)).setOnClickListener( click -> {
                    Intent intentSend = new Intent(getApplicationContext(),MainActivity.class);
                    intentSend.putExtra(getString(R.string.NB_SHIFT), nbShift);
                    intentSend.putCharSequenceArrayListExtra(getString(R.string.LIST), activityList);
                    startActivity(intentSend);
        });
    }
}
