package edu.polytech.demo_fragment_land_port;

import android.view.View;

public interface OnButtonClickedListener {
    void onButtonClicked(int value);
}
