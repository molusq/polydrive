package edu.polytech.demo_fragment_land_port;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;


public class DetailActivity extends AppCompatActivity {
    private final String TAG = "frallo "+getClass().getSimpleName();

    private int valeur;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        Intent intent=getIntent();
        valeur=intent.getIntExtra(getString(R.string.valueExtra),-1);

        TextView displayValue = findViewById(R.id.editView);
        displayValue.setText( (valeur>=0) ? Integer.toString(valeur):"still none");

    }
}


