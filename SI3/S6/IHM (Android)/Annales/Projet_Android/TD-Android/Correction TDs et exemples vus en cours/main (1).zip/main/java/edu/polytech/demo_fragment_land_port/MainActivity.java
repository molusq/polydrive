package edu.polytech.demo_fragment_land_port;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;


public class MainActivity extends AppCompatActivity implements OnButtonClickedListener {
    private final String TAG = "frallo "+getClass().getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //automatic static fragment_main display

        //todo: if (orientation==landscape) display detailFragment


    }

    // --------------
    // CallBack
    // --------------

    @Override
    public void onButtonClicked(int value) {
        if (value>0) {
                Log.d(TAG,"send value to the DetailActivity =>"+value);
                Intent intent = new Intent(MainActivity.this, DetailActivity.class);
                intent.putExtra(getString(R.string.valueExtra), value);
                startActivity(intent);
        }
    }
}