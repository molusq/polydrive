package edu.fredrallo.td2ex1_levelsensor;

import java.util.Observable;

/**
 * A levelSensor is an Observable
 * it knows the value of the level
 * when the value change, if notifies all the observers
 */
class LevelSensor extends Observable {
    private int currentLevel;

    public LevelSensor() {
        this.currentLevel = 0;
    }

    public void setCurrentLevel(int newLevel) {
        currentLevel=newLevel;
        setChanged();
        notifyObservers(currentLevel);
    }

    public int getCurrentLevel() {return currentLevel; }
}
