package edu.fredrallo.td2ex1_levelsensor;

import android.util.Log;
import android.widget.TextView;

import java.util.Observable;
import java.util.Observer;

/**
 * the Cabin is an observer (to the level floor)
 * It Knows the Display class reference (IDisplay interface)
 * it demands to display the new floor's value each time it is notified that the level floor has changed
 *
 * NOTE: the responsibility for the value to be displayed lies with this Cabin
 */
public class Cabin implements Observer  {
    private IDisplay controller;

    public Cabin(IDisplay controller) {
        this.controller = controller;
    }

    @Override
    public void update(Observable o, Object arg) {
        //nothing else to do but ask controller to change displayed value of the level
        int currentLevel = (Integer)arg;
        controller.displayLevel("Level: "+ (currentLevel>=0 ? currentLevel : "???"));
    }
}
