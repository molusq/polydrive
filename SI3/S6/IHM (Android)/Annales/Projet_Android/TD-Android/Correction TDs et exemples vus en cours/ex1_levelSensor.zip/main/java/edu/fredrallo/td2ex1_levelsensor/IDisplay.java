package edu.fredrallo.td2ex1_levelsensor;

/**
 * the class which implements this interface must be able to display the level
 */
public interface IDisplay {
    void displayLevel(String stringToDisplayed);
}
