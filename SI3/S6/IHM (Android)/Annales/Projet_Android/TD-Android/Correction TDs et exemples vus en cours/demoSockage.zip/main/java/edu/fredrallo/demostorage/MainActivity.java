package edu.fredrallo.demostorage;


import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.provider.MediaStore;

import android.util.Log;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;

/**
 * take a picture then save it
 *
 * ask user permission to load/save  (manifest + user permission management)
 * try to load/save picture file in EXTERNAL FOLDER (=/=SD card)  ==> /data/user/0/edu.fredrallo.demostorage/app_imageDir/
 * to display External folder file(s) in emulator ==> go to menu: <VIEW>/<TOOLS>/<Device File Explorer>  and browse  /data/data/<package>/app_imageDir/
 * NOT tested with SDCARD (real device)
 */
public class MainActivity extends AppCompatActivity {
    private static final float TRANSPARENT = 0.3f;
    private static final float OPAQUE = 1;
    private static final String PICTURE_NAME = "_test.jpg";
    private final String TAG = "frallo_"+getClass().getSimpleName();
    private Bitmap picture = null;

    private File internalDirectory;
    private File externalPrimaryDirectory;
    private File externalSecondaryDirectory;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        internalDirectory = new File(getDir("imageDir", Context.MODE_PRIVATE).toString() );
        File[] externalDirectory = getExternalFilesDirs(null);
        if (externalDirectory.length>0) {  //only External primary storage exists
            externalPrimaryDirectory = new File(externalDirectory[0] + "/app_imageDir/" );
            if(!externalPrimaryDirectory.exists()) externalPrimaryDirectory.mkdirs();
        }
        if (externalDirectory.length>1) {  //at least one External secondary storage exists
            externalSecondaryDirectory = new File(externalDirectory[1] + "/app_imageDir/" );
            if(!externalSecondaryDirectory.exists()) externalSecondaryDirectory.mkdirs();
        }

        Log.d(TAG,"log started.");
        Log.d(TAG,">>>>>>>>>>>> internalDirectory =  "+internalDirectory);
        Log.d(TAG,">>>>>>>>>>>> externalPrimaryDirectory =  "+externalPrimaryDirectory);
        Log.d(TAG,">>>>>>>>>>>> externalSecondaryDirectory =  "+externalSecondaryDirectory);

        findViewById(R.id.button_save_internal).setAlpha( picture!=null && internalDirectory!=null ? OPAQUE : TRANSPARENT) ;
        findViewById(R.id.button_save_external).setAlpha( picture!=null && externalPrimaryDirectory!=null ? OPAQUE : TRANSPARENT) ;
        findViewById(R.id.button_save_sd).setAlpha( picture!=null && externalSecondaryDirectory!=null ? OPAQUE : TRANSPARENT) ;
        findViewById(R.id.button_load_internal).setAlpha( !StorageManager.isEmptyDirectory(internalDirectory) && StorageManager.listFiles(internalDirectory).length>0 ? OPAQUE : TRANSPARENT);
        findViewById(R.id.button_load_external).setAlpha( !StorageManager.isEmptyDirectory(externalPrimaryDirectory) && StorageManager.listFiles(externalPrimaryDirectory).length>0 ? OPAQUE : TRANSPARENT);
        findViewById(R.id.button_load_sd).setAlpha( !StorageManager.isEmptyDirectory(externalSecondaryDirectory) && StorageManager.listFiles(externalSecondaryDirectory).length>0 ? OPAQUE : TRANSPARENT);


        //set listeners
        findViewById(R.id.button_image).setOnClickListener( click -> {
                Log.d(TAG,"want to take a picture");
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);   // Create an implicit intent, for image capture
                startActivityForResult(intent, PermissionFactory.REQUEST_ID_IMAGE_CAPTURE);      // Start camera and wait for the results.
        });

        findViewById(R.id.button_save_internal).setOnClickListener(click -> {
            if (picture!=null) {    //manage authorizations
                Log.d(TAG, "want to save internal " + PICTURE_NAME);
                StorageManager.saveBitmapToStorage(getApplicationContext(), picture, new File(internalDirectory, PICTURE_NAME));
            }
        });

        findViewById(R.id.button_save_external).setOnClickListener(click -> {
            if (picture!=null && PermissionFactory.buildAndCheck(this,Manifest.permission.WRITE_EXTERNAL_STORAGE, externalPrimaryDirectory.toString())) {    //manage authorizations
                Log.d(TAG,"want to save "+ PICTURE_NAME);
                StorageManager.saveBitmapToStorage(getApplicationContext(), picture, new File(externalPrimaryDirectory, PICTURE_NAME));
            }
        });

        findViewById(R.id.button_save_sd).setOnClickListener(click -> {
            if (picture!=null && PermissionFactory.buildAndCheck(this,Manifest.permission.WRITE_EXTERNAL_STORAGE, externalSecondaryDirectory.toString())) {    //manage authorizations
                Log.d(TAG,"want to save "+ PICTURE_NAME);
                StorageManager.saveBitmapToStorage(getApplicationContext(), picture, new File(externalSecondaryDirectory, PICTURE_NAME));
            }
        });


        findViewById(R.id.button_load_internal).setOnClickListener(click -> {
            if ( !StorageManager.isEmptyDirectory(internalDirectory) && StorageManager.listFiles(internalDirectory).length>0 ) {    //manage authorizations
                Log.d(TAG,"want to load internal "+ PICTURE_NAME);
                loadImage(new File(internalDirectory, PICTURE_NAME), findViewById(R.id.imageView));
            }
        });

        findViewById(R.id.button_load_external).setOnClickListener(click -> {
            if (!StorageManager.isEmptyDirectory(externalPrimaryDirectory) && StorageManager.listFiles(externalPrimaryDirectory).length>0 && PermissionFactory.buildAndCheck(this,Manifest.permission.READ_EXTERNAL_STORAGE , externalPrimaryDirectory.toString())) {    //manage authorizations
                Log.d(TAG,"want to load "+ PICTURE_NAME);
                StorageManager.loadBitmapFromStorage(new File(externalPrimaryDirectory, PICTURE_NAME), findViewById(R.id.imageView));
            }
        });

        findViewById(R.id.button_load_sd).setOnClickListener(click -> {
            if (!StorageManager.isEmptyDirectory(externalSecondaryDirectory) && StorageManager.listFiles(externalSecondaryDirectory).length>0 && PermissionFactory.buildAndCheck(this,Manifest.permission.READ_EXTERNAL_STORAGE , externalSecondaryDirectory.toString())) {    //manage authorizations
                Log.d(TAG,"want to load "+ PICTURE_NAME);
                StorageManager.loadBitmapFromStorage(new File(externalSecondaryDirectory, PICTURE_NAME), findViewById(R.id.imageView));
            }
        });

    }


    /**
     * load an Image then allow save buttons
     * @param file
     * @param imageView
     */
    private void loadImage(File file, ImageView imageView){
        StorageManager.loadBitmapFromStorage(file, imageView);
        picture = ((BitmapDrawable)imageView.getDrawable()).getBitmap();
        findViewById(R.id.button_save_internal).setAlpha( picture!=null && internalDirectory!=null ? OPAQUE : TRANSPARENT) ;
        findViewById(R.id.button_save_external).setAlpha( picture!=null && externalPrimaryDirectory!=null ? OPAQUE : TRANSPARENT) ;
        findViewById(R.id.button_save_sd).setAlpha( picture!=null && externalSecondaryDirectory!=null ? OPAQUE : TRANSPARENT) ;
    }

    /**
     * what user wanted to do before permission to access external storage was granted
     * @param action: possible values are WRITE_EXTERNAL_STORAGE and READ_EXTERNAL_STORAGE
     */
    private void actionAfterCallbackIfPermissionGranted(String action, String folder){
        File directory = new File (folder);
        Log.d(TAG,"directory = "+directory);
        switch (action) {
            case Manifest.permission.WRITE_EXTERNAL_STORAGE:
                    Log.d(TAG,"action when permission granted ==> save");
                    StorageManager.saveBitmapToStorage(getApplicationContext(), picture, new File(directory, PICTURE_NAME));
                    findViewById(R.id.button_load_external).setAlpha( StorageManager.listFiles(directory).length>0 ? OPAQUE : TRANSPARENT) ;
                    Toast.makeText(getApplicationContext(), "file saved in "+directory, Toast.LENGTH_LONG).show();
                    break;

            case Manifest.permission.READ_EXTERNAL_STORAGE:
                    Log.d(TAG,"action when permission granted ==> load");
                    loadImage(new File(directory, PICTURE_NAME), findViewById(R.id.imageView));
                    Toast.makeText(getApplicationContext(), "file load from "+directory, Toast.LENGTH_LONG).show();
                    break;
        }
    }


    /**
     * callback from PermissionFactory builAndCheck
     * @param requestCode
     * @param result
     * @param grantResults
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, String result[], int[] grantResults) {
        Log.d(TAG,"onRequestPermissionsResult : requestCode="+requestCode+"    grantResults.length="+grantResults.length);
        switch (requestCode) {
            case PermissionFactory.PERMISSIONS_REQUEST_READ_MEDIA:
                            if ((grantResults.length >0 ) && (grantResults[0] == PackageManager.PERMISSION_GRANTED)) {  //length==2 when (permission + arg) received
                                actionAfterCallbackIfPermissionGranted(result[0], result[1]);
                                Log.d(TAG,"onRequestPermissionsResult : permission granted");
                            }
                            else { //not granted
                                AlertDialog.Builder builder = new AlertDialog.Builder(this);  //"this" and not getApplicationContext()... bug?
                                builder.setTitle("Permisions");
                                builder.setMessage("You don't have granted permission... " +
                                        "It's your choice! Note that is necessary to load and save pictures into your device.\n" +
                                        "So, please reconsider issues :)");
                                builder.setNeutralButton("OK", null);
                                builder.show();
                                Log.d(TAG,"onRequestPermissionsResult : permission not granted");
                            }
                            break;
            default:        //other permission
                            AlertDialog.Builder builder = new AlertDialog.Builder(this);
                            builder.setTitle("Permisions");
                            builder.setMessage("Not sur you need this permission... ");
                            builder.setNeutralButton("OK", null);
                            builder.show();
                            Log.d(TAG,"onRequestPermissionsResult : odd permission!");
                            break;
        }
    }


    /**
     * callback from camera activity
     * The Android Camera application encodes the photo in the return Intent delivered to onActivityResult()
     * as a small Bitmap in the extras, under the key "data"  ---> BEURK!!!  no constant!
     *https://developer.android.com/training/camera/photobasics
     *
     * @param requestCode
     * @param resultCode
     * @param data
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PermissionFactory.REQUEST_ID_IMAGE_CAPTURE) {
            switch (resultCode) {
                case RESULT_OK:         picture = (Bitmap) data.getExtras().get("data");
                                        ((ImageView)findViewById(R.id.imageView)).setImageBitmap(picture);
                                        Log.d(TAG,"camera result: RESULT_OK");
                                        findViewById(R.id.button_save_internal).setAlpha(internalDirectory!=null ? OPAQUE : TRANSPARENT);
                                        findViewById(R.id.button_save_external).setAlpha(externalPrimaryDirectory!=null ? OPAQUE : TRANSPARENT);
                                        findViewById(R.id.button_save_sd).setAlpha(externalSecondaryDirectory!=null ? OPAQUE : TRANSPARENT);
                                        break;
                case RESULT_CANCELED:   Toast.makeText(getApplicationContext(), "Action canceled", Toast.LENGTH_LONG).show();
                                        Log.d(TAG,"camera result: RESULT_CANCELED");
                                        findViewById(R.id.button_save_internal).setAlpha(TRANSPARENT);
                                        findViewById(R.id.button_save_external).setAlpha(TRANSPARENT);
                                        findViewById(R.id.button_save_sd).setAlpha(TRANSPARENT);
                                        //TODO: ask why it is important to grant permission to this app
                                        break;
                default:                Toast.makeText(getApplicationContext(), "camera result: Action Failed", Toast.LENGTH_LONG).show();
                                        break;
            }//end switch
        }
    }


}
