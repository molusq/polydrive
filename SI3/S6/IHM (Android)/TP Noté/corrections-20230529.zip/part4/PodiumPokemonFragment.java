package edu.frallo.myapplication;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.squareup.picasso.Picasso;

import java.util.List;
import java.util.Observable;
import java.util.Observer;

/**
 * A simple {@link Fragment} subclass.
 * create an instance of this fragment.
 */
public class PodiumPokemonFragment extends Fragment {
    private final String TAG = "fredrallo "+getClass().getSimpleName();


    //private List<Pokemon> podium;
    public PodiumPokemonFragment() {
        //if (Pokemon.completeList==null) new Throwable("Pokemon's completeList is null");
    }






    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_podium_pokemon, container, false);

        return view;
    }





}