package edu.frallo.myapplication;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Observable;
import java.util.stream.Collectors;


/**
 *  get Pokemons from json data
 *  - no constructor because 'jackson' librairy is used to parse json -> Pokemon
 *  - tuto to use jackson lib: <a href="https://stackoverflow.com/questions/60750796/how-to-convert-this-json-to-object-in-java-android">...</a>
 *  - add in Gradle -->  implementation 'com.google.code.gson:gson:2.8.6'
 *
 *  data : <a href="https://raw.githubusercontent.com/fanzeyi/pokemon.json/17d33dc111ffcc12b016d6485152aa3b1939c214/pokedex.json">...</a>
 *  sprites : <a href="https://github.com/fanzeyi/pokemon.json/tree/master/sprites">...</a>
 *  images : <a href="https://github.com/fanzeyi/pokemon.json/tree/master/images">...</a>
 *
 * @author Frédéric RALLO - March 2023
 */
public class Pokemon {
    public static String language;
    private final String TAG = "fredrallo "+getClass().getSimpleName();
    public static List<Pokemon> completeList =new ArrayList<Pokemon>();


    private int id;
    private Map<String, String> name; //depends of settings language
    private final List<Types> type = new ArrayList<>();
    private Map<String, Integer> base;  //json name is base
    private String pictureURL;


    public Pokemon(){
        super();
        completeList.add(this);
    }

    /**
     * change speed of all NORMAL Type Pokemon
     * @param boost
     */
    public static void boost(int boost) {
        completeList.forEach( pokemon -> {
            if(pokemon.type.contains(Types.NORMAL)) {
                pokemon.base.put(Stats.Speed.toString(), pokemon.base.get(Stats.Speed.toString()) + boost);
            }
        });
    }


    public void setId(int id) {
        pictureURL = "https://github.com/fanzeyi/pokemon.json/blob/master/images/" + String.format("%03d", id) +".png?raw=true";
        this.id = id;
    }

    public void setName(Map<String, String> name) {
        this.name = name;
    }

    public void setBase(Map<String, Integer> base) {
        this.base = base;
    }

    public void setType(List<String> stringType) {
        stringType.forEach( t -> type.add(Types.valueOf(t.toUpperCase())) );
    }


    public int getId() {
        return id;
    }
    public String getPictureURL() {
        return pictureURL;
    }

    public String getName() {
        return name.get(MainActivity.language);
    }
    public List<Types> getTypes() {
        return type;
    }
    public int getBaseValue(Stats stat){
        return base.get(stat.toString());
    }

    public Integer getRank(){
        return 4*base.get("Speed") + 3*base.get("Attack") + 2*base.get("Defense")  + base.get("HP");
    }





    @Override
    public String toString() {
        return "Pokemon{ id=" + id + ", name=" + getName() + ", type=" + type + ", features=" + base + '}';
    }


}



//TODO: constants are not uppercase....
enum Stats {
    HP(0),
    Attack(0),
    Defense(0),
    SP_ATTACK(0),
    SP_DEFENSE(0),
    Speed(0);
    private int value;


    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }
    Stats(int value) {
        this.value=value;
    }

}

enum Types{
    NORMAL,
    FIGHTING,
    FLYING,
    POISON,
    GROUND,
    ROCK,
    BUG,
    GHOST,
    STEEL,
    FIRE,
    WATER,
    GRASS,
    ELECTRIC,
    PSYCHIC,
    ICE,
    DRAGON,
    DARK,
    FAIRY
}

