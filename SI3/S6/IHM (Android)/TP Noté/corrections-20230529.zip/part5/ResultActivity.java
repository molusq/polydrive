package edu.frallo.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.util.Log;

public class ResultActivity extends AppCompatActivity  implements FragmentNotifiable{
    private final String TAG = "fredrallo "+getClass().getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
    }

    @Override
    public void onFragmentNotify(Fragment fragment) {
        //
        Log.d(TAG,"fragment : "+fragment.getClass().getSimpleName());
    }
}