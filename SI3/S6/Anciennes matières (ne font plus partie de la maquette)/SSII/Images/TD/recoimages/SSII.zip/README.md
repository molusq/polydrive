# Reconnaissance images

1. Pour tester la reconnaissance par k-means à des classes  préexistantes, mettre les images de classification au même niveau que le script et les images de test dans un dossier compared_images et utilisez le script recoimages2018.py

2. Pour tester la regression logistique, la localisation des images est a même. Le script à lancer est logistic_regression.py