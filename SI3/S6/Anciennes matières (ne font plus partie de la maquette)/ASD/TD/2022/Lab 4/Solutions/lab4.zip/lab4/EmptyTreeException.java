package ads.lab4;

/**
 * An exception class for empty tree
 */
@SuppressWarnings("serial")
public class EmptyTreeException extends Exception {
	
	public EmptyTreeException() {
		super();
	}
}
