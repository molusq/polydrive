package ads.lab9;

@SuppressWarnings("serial")
public class BadTreeException extends RuntimeException {

	public BadTreeException() {
		super();
	}
}
