package ads.lab8;

import java.util.*;
import ads.graph.*;

/**
 * A class for topological sorting
 */
public class TopSort {
	
	/**
	 * Returns the list of vertices of 'G' in
	 * (one) topological order
	 */
	public static List<Vertex> sort1(DiGraph G) {
		Map<Vertex,Integer> inDegree = new HashMap<Vertex,Integer>();
		Queue<Vertex> queue = new LinkedList<Vertex>();
		List<Vertex> sorted = new LinkedList<Vertex>();

		return sorted;
	}
	
	/**
	 * Returns the list of vertices of 'G' in
	 * (one) topological order
	 */
	public static List<Vertex> sort2(DiGraph G) {
		Set<Vertex> visited = new HashSet<Vertex>();
		List<Vertex> sorted = new LinkedList<Vertex>();

		return sorted;
	}
	
	/**
	 * Visit the graph 'G' using DFS from vertex 'u' and add all the visited
	 * vertices in 'sorted' such that they appear in topological order
	 */
	private static void visit(DiGraph G, Vertex u, Set<Vertex> visited, List<Vertex> sorted) {

	}

	/////////////// 
	
	public static void main(String[] s) {
		DiGraph G = GraphReader.DD4;
		System.out.println(TopSort.sort2(G));
	}	
}
