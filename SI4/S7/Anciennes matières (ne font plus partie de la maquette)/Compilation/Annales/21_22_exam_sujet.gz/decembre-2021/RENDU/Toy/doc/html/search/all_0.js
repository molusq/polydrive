var searchData=
[
  ['_5fdie_0',['_die',['../utils_8h.html#a96534a0bf03c02e14cf372d82c958659',1,'_die(char *message, char *file, int line):&#160;utils.c'],['../utils_8c.html#a96534a0bf03c02e14cf372d82c958659',1,'_die(char *message, char *file, int line):&#160;utils.c']]],
  ['_5fmust_5fmalloc_1',['_must_malloc',['../utils_8c.html#a2dd14da5d217868a960a717bee1709be',1,'_must_malloc(size_t n, char *file, int line):&#160;utils.c'],['../utils_8h.html#a2dd14da5d217868a960a717bee1709be',1,'_must_malloc(size_t n, char *file, int line):&#160;utils.c']]],
  ['_5ftoy_5fbool_2',['_toy_bool',['../toy-runtime_8h.html#add81e6c3adb3a93ecd8ab290cd0b738e',1,'toy-runtime.h']]],
  ['_5ftoy_5ffloat_3',['_toy_float',['../toy-runtime_8h.html#ae6dc4712764f8cb00ba7ab72ea95b458',1,'toy-runtime.h']]],
  ['_5ftoy_5fint_4',['_toy_int',['../toy-runtime_8h.html#ae115db16b42030a9bc84a73b0e1d1fb3',1,'toy-runtime.h']]],
  ['_5ftoy_5fpowint_5',['_toy_powint',['../toy-runtime_8c.html#a42c125bc3f415f206dfd070094a14678',1,'_toy_powint(int a, int b):&#160;toy-runtime.c'],['../toy-runtime_8h.html#a42c125bc3f415f206dfd070094a14678',1,'_toy_powint(int a, int b):&#160;toy-runtime.c']]],
  ['_5ftoy_5fprint_5fbool_6',['_toy_print_bool',['../toy-runtime_8c.html#afeec48f3ae57866893179067a055f3c7',1,'_toy_print_bool(char o):&#160;toy-runtime.c'],['../toy-runtime_8h.html#afeec48f3ae57866893179067a055f3c7',1,'_toy_print_bool(char o):&#160;toy-runtime.c']]],
  ['_5ftoy_5fprint_5ffloat_7',['_toy_print_float',['../toy-runtime_8c.html#a5ce0bc87b384f195e35de3eb0b418f28',1,'_toy_print_float(float o):&#160;toy-runtime.c'],['../toy-runtime_8h.html#a5ce0bc87b384f195e35de3eb0b418f28',1,'_toy_print_float(float o):&#160;toy-runtime.c']]],
  ['_5ftoy_5fprint_5fint_8',['_toy_print_int',['../toy-runtime_8c.html#a3caa3f94b75de63d3b5dc956cba19413',1,'_toy_print_int(int o):&#160;toy-runtime.c'],['../toy-runtime_8h.html#a3caa3f94b75de63d3b5dc956cba19413',1,'_toy_print_int(int o):&#160;toy-runtime.c']]],
  ['_5ftoy_5fprint_5fstring_9',['_toy_print_string',['../toy-runtime_8c.html#a84a6939ae3a550d105e10486d43f01fa',1,'_toy_print_string(_toy_string o):&#160;toy-runtime.c'],['../toy-runtime_8h.html#a84a6939ae3a550d105e10486d43f01fa',1,'_toy_print_string(_toy_string o):&#160;toy-runtime.c']]],
  ['_5ftoy_5fstr_5felement_10',['_toy_str_element',['../toy-runtime_8c.html#a50ea701b86f6ccde2b165fe2cef05884',1,'_toy_str_element(_toy_string s, int n):&#160;toy-runtime.c'],['../toy-runtime_8h.html#aed75a09fcc80b21ed9fc6cbeb059db8c',1,'_toy_str_element(_toy_string s, int idx):&#160;toy-runtime.c']]],
  ['_5ftoy_5fstr_5fslice_11',['_toy_str_slice',['../toy-runtime_8c.html#ae457f0279ed1dc5f631458bf3e1d9608',1,'_toy_str_slice(_toy_string s, int idx1, int idx2):&#160;toy-runtime.c'],['../toy-runtime_8h.html#ae457f0279ed1dc5f631458bf3e1d9608',1,'_toy_str_slice(_toy_string s, int idx1, int idx2):&#160;toy-runtime.c']]],
  ['_5ftoy_5fstrcmp_12',['_toy_strcmp',['../toy-runtime_8c.html#a25903fe90c65768e9bc8eb44b3b93271',1,'_toy_strcmp(_toy_string s1, _toy_string s2):&#160;toy-runtime.c'],['../toy-runtime_8h.html#a25903fe90c65768e9bc8eb44b3b93271',1,'_toy_strcmp(_toy_string s1, _toy_string s2):&#160;toy-runtime.c']]],
  ['_5ftoy_5fstring_13',['_toy_string',['../toy-runtime_8h.html#a61f22124740de12125b54bedb3351388',1,'toy-runtime.h']]],
  ['_5ftrace_5flevel_14',['_trace_level',['../toy-runtime_8c.html#adbaa50c226f960f33f4113881c435713',1,'_trace_level():&#160;toy-runtime.c'],['../toy-runtime_8h.html#adbaa50c226f960f33f4113881c435713',1,'_trace_level():&#160;toy-runtime.c']]]
];
