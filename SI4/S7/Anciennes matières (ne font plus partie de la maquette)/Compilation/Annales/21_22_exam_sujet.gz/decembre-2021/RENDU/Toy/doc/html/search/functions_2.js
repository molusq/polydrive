var searchData=
[
  ['declare_5fsimple_5fvariable_0',['declare_simple_variable',['../symbols_8c.html#abecacf3599c0001388c7a14a8e8a12ad',1,'declare_simple_variable(ast_node *var, ast_node *type):&#160;symbols.c'],['../symbols_8h.html#abecacf3599c0001388c7a14a8e8a12ad',1,'declare_simple_variable(ast_node *var, ast_node *type):&#160;symbols.c']]]
];
