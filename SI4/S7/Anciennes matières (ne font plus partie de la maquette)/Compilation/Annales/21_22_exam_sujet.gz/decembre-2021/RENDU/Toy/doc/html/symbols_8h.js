var symbols_8h =
[
    [ "Symbol_table", "symbols_8h.html#aef297a7529629079a687727284cc1648", null ],
    [ "declare_simple_variable", "symbols_8h.html#abecacf3599c0001388c7a14a8e8a12ad", null ],
    [ "enter_scope", "symbols_8h.html#a12d3970e6e98cbf153d731edd02aeef5", null ],
    [ "init_symbols", "symbols_8h.html#a6a48afec40cbfecd5a959ad94dece194", null ],
    [ "leave_scope", "symbols_8h.html#aec23c18f71447dab5b276aa973a69dfa", null ],
    [ "symbol_table_declare_object", "symbols_8h.html#a3550d7d5521117ab21092d1ac9bc0186", null ],
    [ "symbol_table_free_unused_tables", "symbols_8h.html#adeac0cb33d80a10b645734c7c580dd03", null ],
    [ "symbol_table_replace_prototype", "symbols_8h.html#ad7c912ac18cee1bdd05e10f248b7f438", null ],
    [ "symbol_table_search", "symbols_8h.html#a7c34ffa21da44b7de169667c2328a9f9", null ],
    [ "symbol_table_search_prototype", "symbols_8h.html#a3670fc80dede09681b3f5a8930da3faf", null ]
];