var searchData=
[
  ['_5ftrace_5flevel_0',['_trace_level',['../toy-runtime_8c.html#adbaa50c226f960f33f4113881c435713',1,'_trace_level():&#160;toy-runtime.c'],['../toy-runtime_8h.html#adbaa50c226f960f33f4113881c435713',1,'_trace_level():&#160;toy-runtime.c']]]
];
