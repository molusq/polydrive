var structs__while__statement =
[
    [ "body_stat", "structs__while__statement.html#ae78f7b40bc21d65f57cfa05bf98a633d", null ],
    [ "cond", "structs__while__statement.html#a8f30b6c9b68c5babfc17109357fc6c19", null ],
    [ "header", "structs__while__statement.html#aa254fe4d1fefc68bf19e6ff81d7656cc", null ]
];