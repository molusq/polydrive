var searchData=
[
  ['leave_5ffunc_0',['LEAVE_FUNC',['../toy-runtime_8h.html#ada6b8049c9e2f35312a9d5ea2ccfd7ca',1,'toy-runtime.h']]],
  ['leave_5fvoid_1',['LEAVE_VOID',['../toy-runtime_8h.html#ab25860835046f3170fe2d7a35855ac75',1,'toy-runtime.h']]]
];
