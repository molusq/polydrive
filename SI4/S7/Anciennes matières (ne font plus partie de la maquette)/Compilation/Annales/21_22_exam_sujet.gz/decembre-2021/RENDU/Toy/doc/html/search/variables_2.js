var searchData=
[
  ['body_0',['body',['../structs__function.html#a2f4e7dcd701e3de526e64a1fff558858',1,'s_function']]],
  ['body_5fstat_1',['body_stat',['../structs__while__statement.html#ae78f7b40bc21d65f57cfa05bf98a633d',1,'s_while_statement::body_stat()'],['../structs__for__statement.html#ae78f7b40bc21d65f57cfa05bf98a633d',1,'s_for_statement::body_stat()'],['../structs__foreach__statement.html#ae78f7b40bc21d65f57cfa05bf98a633d',1,'s_foreach_statement::body_stat()']]],
  ['bool_5ftype_2',['bool_type',['../ast_8c.html#a7bf07ba35172c4434e7fe450f1a83297',1,'bool_type():&#160;ast.c'],['../ast_8h.html#a7bf07ba35172c4434e7fe450f1a83297',1,'bool_type():&#160;ast.h']]]
];
