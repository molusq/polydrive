var structs__type =
[
    [ "default_init", "structs__type.html#a5f6959f4a996710f8c0ceb7b09a03653", null ],
    [ "header", "structs__type.html#aa254fe4d1fefc68bf19e6ff81d7656cc", null ],
    [ "is_standard", "structs__type.html#a84a6a40d40725c93843bcf7477fc8e5e", null ],
    [ "name", "structs__type.html#a5ac083a645d964373f022d03df4849c8", null ]
];