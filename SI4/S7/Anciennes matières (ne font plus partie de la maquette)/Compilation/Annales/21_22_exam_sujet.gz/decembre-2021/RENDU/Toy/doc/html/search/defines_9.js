var searchData=
[
  ['return_0',['RETURN',['../toy-runtime_8h.html#a6a0e6b80dd3d5ca395cf58151749f5e2',1,'toy-runtime.h']]],
  ['return_5fvalue_1',['RETURN_VALUE',['../toy-runtime_8h.html#a0f8d786919a8c514e3ecbc239d241f6a',1,'toy-runtime.h']]]
];
