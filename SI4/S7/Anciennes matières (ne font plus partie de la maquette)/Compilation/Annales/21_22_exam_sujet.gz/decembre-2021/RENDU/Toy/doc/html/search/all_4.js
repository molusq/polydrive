var searchData=
[
  ['data_0',['data',['../structs__list__item.html#a735984d41155bc1032e09bece8f8d66d',1,'s_list_item']]],
  ['declare_5fsimple_5fvariable_1',['declare_simple_variable',['../symbols_8c.html#abecacf3599c0001388c7a14a8e8a12ad',1,'declare_simple_variable(ast_node *var, ast_node *type):&#160;symbols.c'],['../symbols_8h.html#abecacf3599c0001388c7a14a8e8a12ad',1,'declare_simple_variable(ast_node *var, ast_node *type):&#160;symbols.c']]],
  ['def_5fast_2',['DEF_AST',['../ast_8c.html#a6faf3f74675377c074c3939ff4cea445',1,'ast.c']]],
  ['def_5fast0_3',['DEF_AST0',['../ast_8c.html#addd5fd4aabd225d95d2a7a3787ff07d5',1,'ast.c']]],
  ['default_5finit_4',['default_init',['../structs__type.html#a5f6959f4a996710f8c0ceb7b09a03653',1,'s_type']]],
  ['die_5',['die',['../utils_8h.html#ab6acaec854169756098dfd26138a1a0e',1,'utils.h']]]
];
