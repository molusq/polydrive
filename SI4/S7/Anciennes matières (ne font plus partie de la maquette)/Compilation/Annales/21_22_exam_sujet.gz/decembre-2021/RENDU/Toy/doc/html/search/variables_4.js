var searchData=
[
  ['data_0',['data',['../structs__list__item.html#a735984d41155bc1032e09bece8f8d66d',1,'s_list_item']]],
  ['default_5finit_1',['default_init',['../structs__type.html#a5f6959f4a996710f8c0ceb7b09a03653',1,'s_type']]]
];
