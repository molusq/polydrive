var toy_runtime_8h =
[
    [ "ENTER_FUNC", "toy-runtime_8h.html#a3ee9d957fc25b6cc9fd2bb3b252cae12", null ],
    [ "ENTER_VOID", "toy-runtime_8h.html#a00782f937ac9f4f3f96a08f354e40dc9", null ],
    [ "LEAVE_FUNC", "toy-runtime_8h.html#ada6b8049c9e2f35312a9d5ea2ccfd7ca", null ],
    [ "LEAVE_VOID", "toy-runtime_8h.html#ab25860835046f3170fe2d7a35855ac75", null ],
    [ "RETURN", "toy-runtime_8h.html#a6a0e6b80dd3d5ca395cf58151749f5e2", null ],
    [ "RETURN_VALUE", "toy-runtime_8h.html#a0f8d786919a8c514e3ecbc239d241f6a", null ],
    [ "UNSPECIFIED_SLICE_LIMIT", "toy-runtime_8h.html#a3377557e8453f067e8cfb2fd0a6917e1", null ],
    [ "_toy_bool", "toy-runtime_8h.html#add81e6c3adb3a93ecd8ab290cd0b738e", null ],
    [ "_toy_float", "toy-runtime_8h.html#ae6dc4712764f8cb00ba7ab72ea95b458", null ],
    [ "_toy_int", "toy-runtime_8h.html#ae115db16b42030a9bc84a73b0e1d1fb3", null ],
    [ "_toy_string", "toy-runtime_8h.html#a61f22124740de12125b54bedb3351388", null ],
    [ "_toy_powint", "toy-runtime_8h.html#a42c125bc3f415f206dfd070094a14678", null ],
    [ "_toy_print_bool", "toy-runtime_8h.html#afeec48f3ae57866893179067a055f3c7", null ],
    [ "_toy_print_float", "toy-runtime_8h.html#a5ce0bc87b384f195e35de3eb0b418f28", null ],
    [ "_toy_print_int", "toy-runtime_8h.html#a3caa3f94b75de63d3b5dc956cba19413", null ],
    [ "_toy_print_string", "toy-runtime_8h.html#a84a6939ae3a550d105e10486d43f01fa", null ],
    [ "_toy_str_element", "toy-runtime_8h.html#aed75a09fcc80b21ed9fc6cbeb059db8c", null ],
    [ "_toy_str_slice", "toy-runtime_8h.html#ae457f0279ed1dc5f631458bf3e1d9608", null ],
    [ "_toy_strcmp", "toy-runtime_8h.html#a25903fe90c65768e9bc8eb44b3b93271", null ],
    [ "_trace_level", "toy-runtime_8h.html#adbaa50c226f960f33f4113881c435713", null ]
];