var searchData=
[
  ['c_5fbody_0',['c_body',['../structs__function.html#af3553b0bad98437865b16ce775b25007',1,'s_function']]],
  ['callee_1',['callee',['../structs__call.html#a1e47fdf46d402eeeca8ad52a3515acd4',1,'s_call']]],
  ['cast_2',['cast',['../structast__node.html#ac9d86214883bfac1fd16c96ed35d810a',1,'ast_node::cast()'],['../structs__expression.html#a81e0443dd6df159f349e6f9141ee7dc5',1,'s_expression::cast()']]],
  ['cond_3',['cond',['../structs__if__statement.html#a8f30b6c9b68c5babfc17109357fc6c19',1,'s_if_statement::cond()'],['../structs__while__statement.html#a8f30b6c9b68c5babfc17109357fc6c19',1,'s_while_statement::cond()']]]
];
