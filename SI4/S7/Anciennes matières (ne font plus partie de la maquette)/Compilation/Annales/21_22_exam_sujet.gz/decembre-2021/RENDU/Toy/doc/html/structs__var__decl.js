var structs__var__decl =
[
    [ "header", "structs__var__decl.html#aa254fe4d1fefc68bf19e6ff81d7656cc", null ],
    [ "is_static", "structs__var__decl.html#a304fbadb59a0f16927a48adfff3dd25f", null ],
    [ "vars", "structs__var__decl.html#a079cb3e6c0865b8ff0eab4cb2dd5ffd6", null ]
];