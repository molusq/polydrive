var searchData=
[
  ['table_0',['table',['../structhash__table.html#a762183d8f58832cf65e8ad9506b98efb',1,'hash_table::table()'],['../structsymbol__table.html#ab61feff1c6047222b65d5bd51d837c79',1,'symbol_table::table()']]],
  ['then_5fstat_1',['then_stat',['../structs__if__statement.html#ad302af6d65b98650ce603807a2ea64ba',1,'s_if_statement']]],
  ['trace_5fmode_2',['trace_mode',['../main_8c.html#ad976cf74f8d204b855330eb261d699f8',1,'trace_mode():&#160;main.c'],['../toy_8h.html#ad976cf74f8d204b855330eb261d699f8',1,'trace_mode():&#160;main.c']]],
  ['type_3',['type',['../structast__node.html#aefb0f1c0ed419ceb923d1a64496dbcf1',1,'ast_node::type()'],['../structs__foreach__statement.html#aefb0f1c0ed419ceb923d1a64496dbcf1',1,'s_foreach_statement::type()']]]
];
