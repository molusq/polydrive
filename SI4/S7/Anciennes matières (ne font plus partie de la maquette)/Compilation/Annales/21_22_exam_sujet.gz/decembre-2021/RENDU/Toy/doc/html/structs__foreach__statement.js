var structs__foreach__statement =
[
    [ "body_stat", "structs__foreach__statement.html#ae78f7b40bc21d65f57cfa05bf98a633d", null ],
    [ "header", "structs__foreach__statement.html#aa254fe4d1fefc68bf19e6ff81d7656cc", null ],
    [ "lst", "structs__foreach__statement.html#a7020f44bb35ba3d039610ff736395c73", null ],
    [ "type", "structs__foreach__statement.html#aefb0f1c0ed419ceb923d1a64496dbcf1", null ],
    [ "var", "structs__foreach__statement.html#ac9f90b1549fa7f0c5d26b17b13819533", null ]
];