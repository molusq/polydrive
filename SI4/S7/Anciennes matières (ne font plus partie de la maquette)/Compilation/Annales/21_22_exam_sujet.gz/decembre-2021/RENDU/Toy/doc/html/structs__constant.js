var structs__constant =
[
    [ "fvalue", "structs__constant.html#a1a264ee74fe033b1d37a761dec726963", null ],
    [ "header", "structs__constant.html#aa254fe4d1fefc68bf19e6ff81d7656cc", null ],
    [ "ivalue", "structs__constant.html#a3d99fe1c085dab7f403f694528f530ee", null ],
    [ "svalue", "structs__constant.html#a3d4ba70c89bb0a94c439f9d2939888d5", null ],
    [ "value", "structs__constant.html#a71353c0e78be24a2369b2ec80d61a802", null ]
];