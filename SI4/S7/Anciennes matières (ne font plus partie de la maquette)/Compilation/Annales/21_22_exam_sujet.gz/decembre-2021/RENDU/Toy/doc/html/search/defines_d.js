var searchData=
[
  ['vardecl_5fstatic_0',['VARDECL_STATIC',['../ast_8h.html#a7884da1b21d7b9517d36ae7411d49d7d',1,'ast.h']]],
  ['vardecl_5fvars_1',['VARDECL_VARS',['../ast_8h.html#acad213108ac0659f572518a34c45f333',1,'ast.h']]]
];
