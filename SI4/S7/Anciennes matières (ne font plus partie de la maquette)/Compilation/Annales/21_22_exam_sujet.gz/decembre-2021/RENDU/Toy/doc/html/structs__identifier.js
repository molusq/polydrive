var structs__identifier =
[
    [ "header", "structs__identifier.html#aa254fe4d1fefc68bf19e6ff81d7656cc", null ],
    [ "is_const", "structs__identifier.html#a05a1300b80b1b98874164d10b779365a", null ],
    [ "value", "structs__identifier.html#a4e9aec275e566b978a3ccb4e043d8c61", null ]
];