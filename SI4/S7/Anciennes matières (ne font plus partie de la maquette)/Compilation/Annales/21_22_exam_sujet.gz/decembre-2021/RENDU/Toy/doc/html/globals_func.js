var globals_func =
[
    [ "_", "globals_func.html", null ],
    [ "a", "globals_func_a.html", null ],
    [ "d", "globals_func_d.html", null ],
    [ "e", "globals_func_e.html", null ],
    [ "f", "globals_func_f.html", null ],
    [ "h", "globals_func_h.html", null ],
    [ "i", "globals_func_i.html", null ],
    [ "l", "globals_func_l.html", null ],
    [ "m", "globals_func_m.html", null ],
    [ "p", "globals_func_p.html", null ],
    [ "s", "globals_func_s.html", null ],
    [ "y", "globals_func_y.html", null ]
];