var searchData=
[
  ['_5ftoy_5fbool_0',['_toy_bool',['../toy-runtime_8h.html#add81e6c3adb3a93ecd8ab290cd0b738e',1,'toy-runtime.h']]],
  ['_5ftoy_5ffloat_1',['_toy_float',['../toy-runtime_8h.html#ae6dc4712764f8cb00ba7ab72ea95b458',1,'toy-runtime.h']]],
  ['_5ftoy_5fint_2',['_toy_int',['../toy-runtime_8h.html#ae115db16b42030a9bc84a73b0e1d1fb3',1,'toy-runtime.h']]],
  ['_5ftoy_5fstring_3',['_toy_string',['../toy-runtime_8h.html#a61f22124740de12125b54bedb3351388',1,'toy-runtime.h']]]
];
