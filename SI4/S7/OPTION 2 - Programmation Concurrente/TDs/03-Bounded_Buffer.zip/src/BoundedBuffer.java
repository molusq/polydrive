/*
@author  j.n.magee 14/11/96
@modified riveill 31/08/21 remove applet
*/
import java.awt.*;
import java.awt.event.*;

public class BoundedBuffer extends Panel {


    ThreadPanel prod;
    ThreadPanel cons;
    BufferCanvas buffDisplay;

    public void init() {
        //super.init();
        // Set up Display
        prod = new ThreadPanel("Producer",Color.blue);
        cons = new ThreadPanel("Consumer",Color.yellow);
        buffDisplay =  new BufferCanvas("Buffer",5);
        GridBagLayout gridbag = new GridBagLayout();
        setLayout(gridbag);
        GridBagConstraints gc = new GridBagConstraints();
        gc.anchor = GridBagConstraints.NORTH;
        gridbag.setConstraints(buffDisplay, gc);
        gridbag.setConstraints(prod, gc);
        gridbag.setConstraints(cons, gc);
        add(prod);
        add(buffDisplay);
        add(cons);
    }

    public void start() {
	System.out.println("start in BoudedBuffer");
        Buffer b = new DisplayBuffer(buffDisplay,5);
        // Create Thread
        prod.start(new Producer(b));
        cons.start(new Consumer(b));
    }

    public void stop() {
        prod.stop();
        cons.stop();
    }

    public static void main(String[] args) {
        Frame f = new Frame();
        f.addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent e) {
                System.exit(0);
            }
        });

        BoundedBuffer ut = new BoundedBuffer();
        f.add(ut);
        f.pack();
        ut.init();
        f.setSize(650, 250);
        f.setVisible(true);
        ut.start();
    }

}

/**************************************************************/

class DisplayBuffer extends BufferImpl {
    BufferCanvas disp_;

    DisplayBuffer(BufferCanvas disp,int size) {
        super(size);
        disp_ = disp;
    }

    private void display() {
        char[] tmp = new char[size];
        for (int i=0; i<size ; i++) {
            if (buf[i] != null)
                tmp[i] = ((Character)buf[i]).charValue();
            else
                tmp[i] = ' ';
        }
        disp_.setvalue(tmp,in,out);
    }

    synchronized public void put(Object o) throws InterruptedException {
        super.put(o);
        display();
        Thread.sleep(400);
    }

    synchronized public Object get() throws InterruptedException {
        Object o = super.get();
        display();
        return (o);
    }

 }

