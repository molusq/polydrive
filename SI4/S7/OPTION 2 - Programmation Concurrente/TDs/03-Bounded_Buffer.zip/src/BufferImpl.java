
/*********************BUFFER*****************************/

public class BufferImpl implements Buffer {

    protected Object[] buf;
    protected int in = 0;
    protected int out= 0;
    protected int count= 0;
    protected int size;

    public BufferImpl(int size) {
        this.size = size;
        buf = new Object[size];
    }

    public synchronized void put(Object o) throws InterruptedException {
        // to be completed
        buf[in] = o;
        ++count;
        in=(in+1) % size;
    }

    public synchronized Object get() throws InterruptedException {
        // to be completed
        Object o =buf[out];
        buf[out]=null;
        --count;
        out=(out+1) % size;
        return (o);
    }
}
