javac *.java
echo "Main-Class: BoundedBuffer" > Manifest.txt 
jar -cmvf Manifest.txt BoundedBuffer.jar *.class
rm *.class Manifest.txt
