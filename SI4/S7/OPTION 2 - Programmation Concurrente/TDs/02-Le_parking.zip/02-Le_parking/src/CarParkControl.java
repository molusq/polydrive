/**
 * Class to be modified
 */

public class CarParkControl {
	protected int spaces;
	protected int capacity;

	CarParkControl(int n) {
		capacity = spaces = n;
	}

	// TO DO: modify arrive
	void arrive() throws InterruptedException {
		// to do
		--spaces;
	}

	// TO DO: modify arrive
	void depart() throws InterruptedException {
		// to do
		++spaces;
	}
}
