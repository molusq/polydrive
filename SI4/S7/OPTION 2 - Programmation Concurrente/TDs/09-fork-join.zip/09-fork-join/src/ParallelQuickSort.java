import java.util.concurrent.RecursiveAction;
import java.util.concurrent.ForkJoinTask;
import java.util.ArrayList;
import java.util.List;


public class ParallelQuickSort extends RecursiveAction {
    private int [] tableau;
    private int debut_a_trier;
    private int fin_a_trier;

    public ParallelQuickSort(int [] tableau, int debut, int fin) {
    	//for (int i=debut; i<=fin; i++) System.out.println(tableau[i]);
    	this.tableau = tableau;
        this.debut_a_trier = debut;
        this.fin_a_trier = fin;
    }

    public void compute() {
    	if (debut_a_trier < fin_a_trier) {
    		if (fin_a_trier-debut_a_trier <= 1000) {
    			// Si on veut limiter la profondeur de l'arbre
    			// on fait de la récursivité si la taille du tableau à trier est petite
    			//System.out.println("reduction recursivité"+"-"+Integer.toString(fin_a_trier-debut_a_trier));
    			int indicePivot = this.partition(tableau, debut_a_trier, fin_a_trier);
    			this.quicksort(tableau, debut_a_trier, indicePivot-1);
    			this.quicksort(tableau, indicePivot+1, fin_a_trier);
    		} else {
				List<ForkJoinTask<Void>> subTasks = new ArrayList<>();
				int indicePivot = this.partition(tableau, debut_a_trier, fin_a_trier);
				// même chose que ci-dessus mais en créant 2 sous-taches qui vont pouvoir s'exécuter en //
				// puis en attendant la terminaison des 2 sous-taches crées
				//System.out.println("creation 2 threads");
			}
    	}
    }

    private void quicksort(int [] tableau, int debut, int fin) {
    	//System.out.println("tri de l'indice " + debut + " à l'indice " + fin);
    	if (debut < fin) {
    		int indicePivot = this.partition(tableau, debut, fin);
    		this.quicksort(tableau, debut, indicePivot-1);
    		this.quicksort(tableau, indicePivot+1, fin);
    	}
    }
    
	private int partition (int [] tableau, int debut, int fin) {
		int d = debut+1;
		int f = fin;
		// A implementer -- exactement même code que pour sequentiel
		return d;
	}
}
