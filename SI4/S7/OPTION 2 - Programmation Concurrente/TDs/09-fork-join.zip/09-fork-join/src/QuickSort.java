public class QuickSort {
    
    public void quicksort(int [] tableau, int debut, int fin) {
    	//System.out.println("tri de l'indice " + debut + " à l'indice " + fin);
    	if (debut < fin) {
    		int indicePivot = partition(tableau, debut, fin);
    		quicksort(tableau, debut, indicePivot-1);
    		quicksort(tableau, indicePivot+1, fin);
    	}
    }

    public int partition (int [] tableau, int debut, int fin) {
    	int valeurPivot = tableau[debut];
    	int d = debut+1;
    	int f = fin;
    	// A Implémenter
    	return d;
    }
}
