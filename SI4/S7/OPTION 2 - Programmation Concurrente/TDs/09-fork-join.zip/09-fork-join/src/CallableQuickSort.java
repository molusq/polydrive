import java.util.Collection;
import java.util.List;
import java.util.concurrent.Future;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Callable;

public class CallableQuickSort implements Callable<String> {

	private int [] tableau;
	private int debut_a_trier;
	private int fin_a_trier;
	private ExecutorService executor;
	private List<Future<String>> futures;

	public CallableQuickSort(int [] tableau, List<Future<String>> futures, ExecutorService executor, int debut, int fin) {
	    this.executor = executor;
	    this.futures = futures;
	    this.tableau = tableau;
	    this.debut_a_trier = debut;
	    this.fin_a_trier = fin;
	}
	
    public String call() throws Exception {
		if (debut_a_trier < fin_a_trier) {
			if (fin_a_trier-debut_a_trier <= 10) {
				// Si on veut limiter la profondeur de l'arbre
				// on fait de la récursivité si la taille du tableau à trier est petite
				//System.out.println("reduction recursivité"+"-"+Integer.toString(fin_a_trier-debut_a_trier));
				int indicePivot = this.partition(tableau, debut_a_trier, fin_a_trier);
				this.quicksort(tableau, debut_a_trier, indicePivot-1);
				this.quicksort(tableau, indicePivot+1, fin_a_trier);
			} else {
				int indicePivot = this.partition(tableau, debut_a_trier, fin_a_trier);
				// Même chose que ci-dessus mais en :
				// - Creant des Callables
				// - Les soumettant à un executeur
				// - en enregistrant le futur dans la liste des futures
			}
		}
		return "OK";
	}

	private void quicksort(int [] tableau, int debut, int fin) {
		//System.out.println("tri de l'indice " + debut + " à l'indice " + fin);
		if (debut < fin) {
			int indicePivot = partition(tableau, debut, fin);
			quicksort(tableau, debut, indicePivot-1);
			quicksort(tableau, indicePivot+1, fin);
		}
	}
	    
	private int partition (int [] tableau, int debut, int fin) {
			int d = debut+1;
			int f = fin;
			// A implementer -- exactement même code que pour sequentiel
			return d;
	 }
}
