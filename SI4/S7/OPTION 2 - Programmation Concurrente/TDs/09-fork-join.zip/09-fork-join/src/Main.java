import java.util.Random;
import java.util.List;
import java.util.Vector;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.RecursiveAction;
import java.util.concurrent.ForkJoinPool;

public class Main {

    static final int MAX_THREAD = 10;
    static final int MAX_SIZE = 100000;

    static void initialise_tableau (int tableau[]) {
    	//System.out.println("Initialise le tableau");
    	Random rand = new Random();
    	for (int i=0; i<tableau.length; i++) {
    		tableau[i] = rand.nextInt(); // random initialisation
    		//tableau[i] = tableau.length-i;
		}
    	//for (int i=0; i<tableau.length; i++)
    	//	System.out.println(tableau[i]);
    }	
    

    static void verifie_tableau (int tableau[]) {
        //System.out.println("Controle du tableau trié de taille " + max);
    	//for (int i=0; i<max; i++) System.out.println(">"+tableau[i]);
        for (int i=0; i<tableau.length-1; i++)
            if (tableau[i]>tableau[i+1]) {
                System.out.println("tableau pas trié correctement : ");
                System.out.println("-->cases: "+i+" - "+tableau[i]);
                System.out.println("-->cases: "+(i+1)+" - "+tableau[i]);
                System.exit(1);
            }
    }

    public static void main(String[] args) {
    	long date_debut=0;
    	int nb_iteration = 5;
    	int temps_total;
    	long temps;

    	int taille;
    	int nb_thread_max;
	
    	if (args.length != 2) {
    		System.out.println("Usage : java Main <taille du tableau> <nbre max de thread>");
    		taille = MAX_SIZE;
    		nb_thread_max = MAX_THREAD;
    	} else {
    		taille = Integer.parseInt(args[0]);
    		nb_thread_max = Integer.parseInt(args[1]);
    	}
    	int tableau[] = new int[taille];
       
    	if (nb_thread_max > MAX_THREAD) nb_thread_max = MAX_THREAD;
    	System.out.println("Execution avec un tableau de taille : " + taille);
    	
        temps_total=0;
	
        System.out.println("");
        System.out.println("--------------------------");
        System.out.println("");

        for (int i=0; i<=nb_iteration; i++) {
        	initialise_tableau (tableau);
        	QuickSort QS = new QuickSort();
        	
        	date_debut = System.nanoTime();
        	QS.quicksort(tableau, 0, taille-1);
            temps=System.nanoTime()-date_debut;
            temps_total += temps;
            
            verifie_tableau(tableau);
            //System.out.println("QuickSort récursif:\t"+temps/1000+" ms");
        }
        System.out.println("Itératif :\t\t"+(temps_total/nb_iteration)/1000+" ms");

        System.out.println("");
        System.out.println("--------------------------");
        System.out.println("");

        List<Future<?>> futures = new Vector<Future<?>>();
        for (int nb_thread=0; nb_thread<=nb_thread_max; nb_thread=nb_thread+2) {
        	ExecutorService executor;
        	if (nb_thread==0) {
            	executor = Executors.newFixedThreadPool(1); // Pour comparer avec approche récursives.
                //System.out.println("Executor QuickSort avec " + 1 + " thread");
        	} else {
            	executor = Executors.newFixedThreadPool(nb_thread); // Pour comparer avec approche ForJoin
        		//System.out.println("Executor QuickSort avec " + nb_thread + " threads");
        	}
        	temps_total=0;
            
            for (int i=0; i<=nb_iteration; i++) {
	            initialise_tableau (tableau);
	            date_debut = System.nanoTime();
	            futures.add(executor.submit(new RunnableQuickSort(tableau, futures, executor, 0, taille-1)));
	            try {
	            	while (!futures.isEmpty()) {
	            		Future top = futures.remove( 0 );
	            		top.get(); // on attend la terminaison de la thread
	            	}
	            } catch (Exception e) {
	            	e.printStackTrace();
	            }
	            temps=System.nanoTime()-date_debut;
	            temps_total += temps;

	            verifie_tableau(tableau);	          
	            //System.out.println("Runnable QuickSort:\t"+temps/1000+" ms");
            }
            executor.shutdown();
            if (nb_thread==0)
            	System.out.println("Executor Runnable: 1 thread :\t"+(temps_total/nb_iteration)/1000+" ms");
            else
            	System.out.println("Executor Runnable: " + nb_thread + " threads :\t"+(temps_total/nb_iteration)/1000+" ms");
        }
        
        System.out.println("");
        System.out.println("--------------------------");
        System.out.println("");

        List<Future<String>> futures2 = new Vector<Future<String>>();
        for (int nb_thread=0; nb_thread<=nb_thread_max; nb_thread=nb_thread+2) {
        	ExecutorService executor;
        	if (nb_thread==0) {
            	executor = Executors.newFixedThreadPool(1); // Pour comparer avec approche récursives.
                //System.out.println("Executor QuickSort avec " + 1 + " thread");
        	} else {
            	executor = Executors.newFixedThreadPool(nb_thread); // Pour comparer avec approche ForJoin
        		//System.out.println("Executor QuickSort avec " + nb_thread + " threads");
        	}
        	temps_total=0;
            
            for (int i=0; i<=nb_iteration; i++) {
            	initialise_tableau (tableau);
	            date_debut = System.nanoTime();
	            futures2.add(executor.submit(new CallableQuickSort(tableau, futures2, executor, 0, taille-1)));
	            try {
	            	while (!futures2.isEmpty()) {
	            		Future<String> top = futures2.remove( 0 );
	            		top.get(); // on attend la terminaison de la thread
	            	}
	            } catch (Exception e) {
	            	e.printStackTrace();
	            }
	            temps=System.nanoTime()-date_debut;
	            temps_total += temps;

	            verifie_tableau(tableau);	          
	            //System.out.println("Callable QuickSort:\t"+temps/1000+" ms");
            }
            executor.shutdown();
            if (nb_thread==0)
            	System.out.println("Executor Callable: 1 thread :\t"+(temps_total/nb_iteration)/1000+" ms");
            else
            	System.out.println("Executor Callable: " + nb_thread + " threads :\t"+(temps_total/nb_iteration)/1000+" ms");
        }
        System.out.println("");
        System.out.println("--------------------------");
        System.out.println("");

        for (int nb_thread=0; nb_thread<=nb_thread_max; nb_thread=nb_thread+2) {
        	ForkJoinPool pool;
            if (nb_thread==0) {
            	continue;
            } else
            	pool = new ForkJoinPool(nb_thread);
            
            temps_total=0;
            //System.out.println("ForkJoin QuickSort avec " + nb_thread + " thread(s)");
            for (int i=0; i<=nb_iteration; i++) {
	            initialise_tableau (tableau);
		        
	            date_debut = System.nanoTime();
	            RecursiveAction fs = new ParallelQuickSort(tableau, 0, taille-1);
	            pool.invoke(fs);
	            temps=System.nanoTime()-date_debut;
	            temps_total += temps;
	            
	            verifie_tableau(tableau);
                //System.out.println("ForkJoin QuickSort:\t"+temps/1000+" ms");
	            
            }
            System.out.println("ForkJoin: " + nb_thread+" thread(s) :\t"+(temps_total/nb_iteration)/1000+" ms");
        }
    }
}

